module.exports = {

"[project]/.next-internal/server/app/api/car/route/actions.js [app-rsc] (server actions loader, ecmascript)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
}}),
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}}),
"[project]/app/lib/data/car.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "dummyCars": ()=>dummyCars
});
const dummyCars = [
    {
        id: 1,
        name: '2023 Tesla Model S Plaid',
        price: 129000,
        image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS0PqAfMWtfAcgO5vo8M5F0wg0ANNriFmlWUw&s',
        location: 'San Jose, CA',
        timeLeft: '2d 3h 11m',
        watchers: 312,
        bids: 52,
        mileage: 3200,
        year: 2023,
        fuelType: 'Electric',
        transmission: 'Automatic',
        seller: 'Tesla Dealer',
        reservePrice: 125000,
        minBid: 1000
    },
    {
        id: 2,
        name: '2022 BMW M5 Competition',
        price: 114500,
        image: 'https://news.dupontregistry.com/wp-content/uploads/2022/09/2022-bmw-m5-cs-1.jpg',
        location: 'Los Angeles, CA',
        timeLeft: '1d 6h 20m',
        watchers: 198,
        bids: 34,
        mileage: 7900,
        year: 2022,
        fuelType: 'Petrol',
        transmission: 'Automatic',
        seller: 'BMW Certified Dealer',
        reservePrice: 110000,
        minBid: 1500
    },
    {
        id: 3,
        name: '2021 Mercedes-Benz S580',
        price: 103000,
        image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQPF93lDlRe4ektKrTnEguHYykeFXuXwyjzXw&s',
        location: 'Dallas, TX',
        timeLeft: '3d 2h 45m',
        watchers: 267,
        bids: 41,
        mileage: 5200,
        year: 2021,
        fuelType: 'Petrol',
        transmission: 'Automatic',
        seller: 'Luxury Auto Group',
        reservePrice: 98000,
        minBid: 2000
    },
    {
        id: 4,
        name: '2023 Audi RS7 Sportback',
        price: 119000,
        image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ4iaxyNoXdZK8JYyLN5HygkEF0Eats_IZE9w&s',
        location: 'New York, NY',
        timeLeft: '2d 5h 5m',
        watchers: 310,
        bids: 46,
        mileage: 3100,
        year: 2023,
        fuelType: 'Petrol',
        transmission: 'Automatic',
        seller: 'Audi Manhattan',
        reservePrice: 115000,
        minBid: 1200
    },
    {
        id: 5,
        name: '2020 Porsche Taycan Turbo',
        price: 98000,
        image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSWqN2EANln9bj2b9J_oqKBBzLmR8_uWCyTFA&s',
        location: 'Miami, FL',
        timeLeft: '4d 4h 30m',
        watchers: 178,
        bids: 29,
        mileage: 8700,
        year: 2020,
        fuelType: 'Electric',
        transmission: 'Automatic',
        seller: 'Porsche South Florida',
        reservePrice: 95000,
        minBid: 1000
    },
    {
        id: 6,
        name: '2022 Lexus LC 500 Convertible',
        price: 104000,
        image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTvSdgKNTZUv6UdvxOuQID7-h9mpCxzq4DrZQ&s',
        location: 'Phoenix, AZ',
        timeLeft: '1d 12h 15m',
        watchers: 132,
        bids: 21,
        mileage: 6400,
        year: 2022,
        fuelType: 'Petrol',
        transmission: 'Automatic',
        seller: 'Lexus of Scottsdale',
        reservePrice: 101000,
        minBid: 900
    },
    {
        id: 7,
        name: '2021 Jaguar F-Type R',
        price: 87000,
        image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRRBc2hFh2siifh_TD7s4O4Uw_FCIxBiISKYw&s',
        location: 'Atlanta, GA',
        timeLeft: '3d 8h 40m',
        watchers: 154,
        bids: 33,
        mileage: 4800,
        year: 2021,
        fuelType: 'Petrol',
        transmission: 'Automatic',
        seller: 'Jaguar Atlanta',
        reservePrice: 85000,
        minBid: 800
    },
    {
        id: 8,
        name: '2022 Cadillac Escalade Sport Platinum',
        price: 109500,
        image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT6EyefvDnnagkq71YTjPke5uNneCnqpIYoRQ&s',
        location: 'Houston, TX',
        timeLeft: '2d 20h 18m',
        watchers: 287,
        bids: 50,
        mileage: 9100,
        year: 2022,
        fuelType: 'Petrol',
        transmission: 'Automatic',
        seller: 'Cadillac Houston',
        reservePrice: 106000,
        minBid: 1400
    },
    {
        id: 9,
        name: '2023 Land Rover Defender 110 V8',
        price: 112000,
        image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQbGa8ksIzbJL8xiqcz-DZ17MnnKhkNhdVpww&s',
        location: 'Denver, CO',
        timeLeft: '3d 11h 55m',
        watchers: 198,
        bids: 37,
        mileage: 2200,
        year: 2023,
        fuelType: 'Petrol',
        transmission: 'Automatic',
        seller: 'Land Rover Denver',
        reservePrice: 109000,
        minBid: 1300
    },
    {
        id: 10,
        name: '2020 Chevrolet Corvette Stingray 3LT',
        price: 88000,
        image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ79d4zeenPBZRLLeUpj4wmfBtZWDJfe-QD1g&s',
        location: 'Chicago, IL',
        timeLeft: '1d 22h 9m',
        watchers: 222,
        bids: 40,
        mileage: 5100,
        year: 2020,
        fuelType: 'Petrol',
        transmission: 'Automatic',
        seller: 'Chevy Performance Dealer',
        reservePrice: 86000,
        minBid: 1000
    },
    {
        id: 11,
        name: '2023 Lucid Air Grand Touring',
        price: 125000,
        image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQBrEwf224BAp7K7jVafQmM--vhcW_n6E7tRg&s',
        location: 'San Francisco, CA',
        timeLeft: '2d 7h 45m',
        watchers: 325,
        bids: 57,
        mileage: 1600,
        year: 2023,
        fuelType: 'Electric',
        transmission: 'Automatic',
        seller: 'Lucid Motors',
        reservePrice: 120000,
        minBid: 1500
    },
    {
        id: 12,
        name: '2021 Nissan GT-R',
        price: 115000,
        image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRjB8xoMTTaG-YMubr2ReoCvxmMFa404ygjhA&s',
        location: 'Las Vegas, NV',
        timeLeft: '2d 5h 10m',
        watchers: 205,
        bids: 38,
        mileage: 7200,
        year: 2021,
        fuelType: 'Petrol',
        transmission: 'Automatic',
        seller: 'GT-R Performance',
        reservePrice: 110000,
        minBid: 1500
    },
    {
        id: 13,
        name: '2022 Ferrari F8 Tributo',
        price: 315000,
        image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTmDgdhbSkEmUhz4FfEzop-iTjur-fob6dvCQ&s',
        location: 'Miami, FL',
        timeLeft: '3d 2h 50m',
        watchers: 340,
        bids: 62,
        mileage: 4800,
        year: 2022,
        fuelType: 'Petrol',
        transmission: 'Automatic',
        seller: 'Ferrari Miami',
        reservePrice: 310000,
        minBid: 2000
    },
    {
        id: 14,
        name: '2023 Porsche Taycan GTS',
        price: 164000,
        image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQW2mmLq4cIT8QpPuinu9YfAnQikFPyGQPtpA&s',
        location: 'San Diego, CA',
        timeLeft: '4d 7h 20m',
        watchers: 188,
        bids: 41,
        mileage: 2300,
        year: 2023,
        fuelType: 'Electric',
        transmission: 'Automatic',
        seller: 'Porsche San Diego',
        reservePrice: 160000,
        minBid: 1200
    },
    {
        id: 15,
        name: '2020 McLaren 720S',
        price: 280000,
        image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQJk1lALZ4QQbAzFDD2ZcQFVEzafYigrVC7rQ&s',
        location: 'Los Angeles, CA',
        timeLeft: '1d 18h 45m',
        watchers: 410,
        bids: 75,
        mileage: 5600,
        year: 2020,
        fuelType: 'Petrol',
        transmission: 'Automatic',
        seller: 'McLaren LA',
        reservePrice: 275000,
        minBid: 2500
    },
    {
        id: 16,
        name: '2022 Aston Martin DB11',
        price: 195000,
        image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQJFKw3aENrnMhpiL8lsiOGM4D85rqITlpzNA&s',
        location: 'Scottsdale, AZ',
        timeLeft: '2d 22h 15m',
        watchers: 164,
        bids: 29,
        mileage: 6200,
        year: 2022,
        fuelType: 'Petrol',
        transmission: 'Automatic',
        seller: 'Aston Martin Scottsdale',
        reservePrice: 190000,
        minBid: 1800
    },
    {
        id: 17,
        name: '2021 Audi RS6 Avant',
        price: 120000,
        image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSwand5WrndkpPrbL0zOtX-82ym8bzxthC8Dg&s',
        location: 'Houston, TX',
        timeLeft: '3d 6h 30m',
        watchers: 202,
        bids: 45,
        mileage: 3900,
        year: 2021,
        fuelType: 'Petrol',
        transmission: 'Automatic',
        seller: 'Audi Houston',
        reservePrice: 115000,
        minBid: 1300
    },
    {
        id: 18,
        name: '2023 BMW M4 Competition',
        price: 82000,
        image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR0NVSTdpOoyKA1hA5f2DWoMCbpXW5wfHAgoQ&s',
        location: 'Atlanta, GA',
        timeLeft: '1d 11h 55m',
        watchers: 142,
        bids: 27,
        mileage: 2800,
        year: 2023,
        fuelType: 'Petrol',
        transmission: 'Automatic',
        seller: 'BMW Atlanta',
        reservePrice: 80000,
        minBid: 1000
    },
    {
        id: 19,
        name: '2022 Lamborghini Urus',
        price: 230000,
        image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTvNdBIh3LmH_uP3eottgHBBaThT3feOsTw_w&s',
        location: 'Dallas, TX',
        timeLeft: '4d 3h 40m',
        watchers: 270,
        bids: 51,
        mileage: 5100,
        year: 2022,
        fuelType: 'Petrol',
        transmission: 'Automatic',
        seller: 'Lamborghini Dallas',
        reservePrice: 225000,
        minBid: 2200
    },
    {
        id: 20,
        name: '2021 Ford GT',
        price: 450000,
        image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ_QOq9nzr7kV54y9RakRPAPt7pvrUAbPVr9Q&s0',
        location: 'Austin, TX',
        timeLeft: '2d 9h 5m',
        watchers: 300,
        bids: 68,
        mileage: 4700,
        year: 2021,
        fuelType: 'Petrol',
        transmission: 'Manual',
        seller: 'Ford Performance',
        reservePrice: 445000,
        minBid: 4000
    },
    {
        id: 21,
        name: '2022 Corvette ZR1',
        price: 125000,
        image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSstH0SjM6fej1S4Z5krBrjqoKQOv1MWDkFOg&s',
        location: 'Chicago, IL',
        timeLeft: '5d 14h 55m',
        watchers: 220,
        bids: 52,
        mileage: 3500,
        year: 2022,
        fuelType: 'Petrol',
        transmission: 'Manual',
        seller: 'Chevy Corvette Club',
        reservePrice: 120000,
        minBid: 1500
    },
    {
        id: 22,
        name: '2023 Dodge Challenger SRT Hellcat',
        price: 85000,
        image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRMQcQN92Wt0sw_flmNtBpi8daEvy7AzDt5zA&s',
        location: 'Phoenix, AZ',
        timeLeft: '3d 12h 20m',
        watchers: 190,
        bids: 33,
        mileage: 6200,
        year: 2023,
        fuelType: 'Petrol',
        transmission: 'Automatic',
        seller: 'Dodge Scottsdale',
        reservePrice: 83000,
        minBid: 1800
    },
    {
        id: 23,
        name: '2021 Jaguar F-Type SVR',
        price: 99000,
        image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQJlM9VZFgRbvwyAVl3VJ_mD3ReynvotH2EFg&s',
        location: 'Miami, FL',
        timeLeft: '2d 10h 10m',
        watchers: 210,
        bids: 44,
        mileage: 4100,
        year: 2021,
        fuelType: 'Petrol',
        transmission: 'Automatic',
        seller: 'Jaguar Miami',
        reservePrice: 95000,
        minBid: 1200
    },
    {
        id: 24,
        name: '2022 Acura NSX Type S',
        price: 170000,
        image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTmPLI9F5wKsnTYlk-kcDu0OxnJ_u1GxiRqYg&s',
        location: 'Orlando, FL',
        timeLeft: '4d 8h 30m',
        watchers: 158,
        bids: 30,
        mileage: 2800,
        year: 2022,
        fuelType: 'Hybrid',
        transmission: 'Automatic',
        seller: 'Acura Orlando',
        reservePrice: 165000,
        minBid: 2000
    },
    {
        id: 25,
        name: '2023 Lotus Emira',
        price: 95000,
        image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR_qoBHCZFBGzKrWSik32KDkx6bNYL17Gt49g&s',
        location: 'San Francisco, CA',
        timeLeft: '1d 6h 40m',
        watchers: 140,
        bids: 26,
        mileage: 1900,
        year: 2023,
        fuelType: 'Petrol',
        transmission: 'Manual',
        seller: 'Lotus Bay Area',
        reservePrice: 92000,
        minBid: 1000
    },
    {
        id: 26,
        name: '2021 Toyota Supra A90',
        price: 60000,
        image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR-fmjTophiJFK_3-I4QFHo8Fs7LKBPRi0vvg&s',
        location: 'Houston, TX',
        timeLeft: '2d 3h 20m',
        watchers: 175,
        bids: 29,
        mileage: 5300,
        year: 2021,
        fuelType: 'Petrol',
        transmission: 'Automatic',
        seller: 'Toyota Houston',
        reservePrice: 58000,
        minBid: 900
    },
    {
        id: 27,
        name: '2022 Mercedes-AMG C63 S',
        price: 85000,
        image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRM2U8P7UdsGGWrs8nN9Bit7u7I-fWLvBqiZw&s',
        location: 'Dallas, TX',
        timeLeft: '3d 15h 25m',
        watchers: 195,
        bids: 37,
        mileage: 4900,
        year: 2022,
        fuelType: 'Petrol',
        transmission: 'Automatic',
        seller: 'Mercedes Dallas',
        reservePrice: 83000,
        minBid: 1200
    },
    {
        id: 28,
        name: '2023 Alfa Romeo Giulia GTA',
        price: 145000,
        image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQSjU-mKM1EAeUofm5ZHdVtLDiurxgCEJ6ClQ&s',
        location: 'New York, NY',
        timeLeft: '4d 5h 0m',
        watchers: 160,
        bids: 32,
        mileage: 2500,
        year: 2023,
        fuelType: 'Petrol',
        transmission: 'Manual',
        seller: 'Alfa Romeo NYC',
        reservePrice: 140000,
        minBid: 1500
    },
    {
        id: 29,
        name: '2021 Dodge Viper ACR',
        price: 160000,
        image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRbAL-BTfbiYU6jthugktyLVr_39edWkD5NrQ&s',
        location: 'Las Vegas, NV',
        timeLeft: '2d 13h 55m',
        watchers: 230,
        bids: 43,
        mileage: 6400,
        year: 2021,
        fuelType: 'Petrol',
        transmission: 'Manual',
        seller: 'Viper Enthusiast',
        reservePrice: 155000,
        minBid: 1800
    },
    {
        id: 30,
        name: '2022 Subaru BRZ tS',
        price: 35000,
        image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS0uKKvwyRTYXoPauc---QwPKkfVM4uYHau0A&s',
        location: 'Seattle, WA',
        timeLeft: '1d 7h 30m',
        watchers: 130,
        bids: 18,
        mileage: 8200,
        year: 2022,
        fuelType: 'Petrol',
        transmission: 'Manual',
        seller: 'Subaru Seattle',
        reservePrice: 33000,
        minBid: 700
    }
];
}),
"[project]/app/api/car/route.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "GET": ()=>GET
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$data$2f$car$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/lib/data/car.js [app-route] (ecmascript)");
;
;
async function GET() {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$data$2f$car$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["dummyCars"]);
}
}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__547747d1._.js.map